package nuist.cn.mymoment.model

data class User(
    val uid: String = "",
    val email: String = "",
    val userName: String = ""
)
